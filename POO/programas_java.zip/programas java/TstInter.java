public class TstInter{
	public static void main(String argc[]){
		Filho f = new Filho();
		f.tela(); //Tio interface
		f.impDados(); // Pai iterface
		f.mostraDados(); //Mae classe-mae herança
	}
}