public class IdException extends Exception{
	
	public IdException(){
		System.out.println("\n Gerou objeto do tipo Exception");
	}

	public void impMsgId(){
		System.out.println("\n Id deve ser maior q 10");
	}
	public void newValId(){
		System.out.println("\n Faca nova entrada");
	}

}