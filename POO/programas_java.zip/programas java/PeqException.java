public class PeqException extends Exception{
	
	public PeqException(){
		System.out.println("\n Gerou objeto do tipo PeqException");
	}

	public void mostra(){
		System.out.println("\n Id deve ser menor q 1000");
	}
	

}