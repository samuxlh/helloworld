public interface Pai{
	double pi = 3.14;
	public void impDados();
}