public class Origem{		//classe entidade
	private int codP;		//atributos
	private String nomeP;	
	
	public void setCodP(int codP){
		this.codP = codP;
	}
	
	public void setNomeP(String nomeP){
		this.nomeP = nomeP;
	}

	public int getCodP(){
		return codP;
	}

	public String getNomeP(){
		return nomeP;
	}

}


