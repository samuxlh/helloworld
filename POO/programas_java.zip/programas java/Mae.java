public class Mae{
	
	public void mostraDados(){
		System.out.println("\n TELA na classe filho");
	}
}