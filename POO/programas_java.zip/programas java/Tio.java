public interface Tio{
	
	public void tela();
}