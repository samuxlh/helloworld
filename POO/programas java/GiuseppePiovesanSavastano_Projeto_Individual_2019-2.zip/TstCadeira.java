/*public class TstCadeira{
	
	public static void main(String arg[]){
	//Cadeira c1 = new Cadeira();	//instancia��o
	Leitura l = new Leitura();
	Service s = new Service();	

	String fraseRetorno = l.inData("\n Informe o nome: \n");	
	
	c1.setPreco(Integer.parseInt(l.inData(" \n Preco:")));
	c1.setMat(l.inData("\n Informe o material: \n"));
	c1.setNumPe(Integer.parseInt(l.inData(" \n N�mero de p�s:")));

	c1.getOrig().setCodP(Integer.parseInt(l.inData(" \n C�digo Postal:")));
	c1.getOrig().setNomeP(l.inData("\n Informe o pa�s: \n"));

	c1.impLocal();

	System.out.println ("\n Nome : " + fraseRetorno);

	System.out.println ("\n Preco : " + c1.getPreco() +"reais");
	System.out.println ("\n Material : " + c1.getMat());
	System.out.println ("\n N�mero de p�s : " + c1.getNumPe());

	System.out.println ("\n C�digo do pa�s : " + c1.getOrig().getCodP());
	System.out.println ("\n Nome do pa�s : " + c1.getOrig().getNomeP());
	}


}*/